/*
This code was written for the TCPA research group to control their muscle twister. 

The code is designed to work with an Arduino Mega 2560 R3 with a rep-rap GPL3 3D printer motor control shield.

The motor control code works by using Timer3 to continually overflow at a defined period that is stored in the variable "Period". 
When Timer3 overflows the TwistISR() interrupt service routine is called. During this ISR, a variable ("TwisterCurrCount" and "LeadCurrCount") 
containing a count of the number of overflows, since the last time their respective motor was pulse, is incremented. Once the number of overflows meets or exceeds 
the motors set limit (stored in "TwisterSetCount" and "LeadSetCount") the motor is pulsed and their counters are reset.

Issues: The impact on the peripherals due to using Timer3 is not fully understood at this point in time. Some software PWM outputs will be non-operational.
  This issue can be fixed by using a different timer at the cost of different peripherals.


Date: 4/18/18
Author: Collin Timmons
*/
#include "TCPATwister.h"

TCPATwister::TCPATwister(){}

/*
 * 
*/

void TCPATwister::TwistISR(){
    if(digitalRead(END_LIMIT) == HIGH  || digitalRead(MOTOR_LIMIT) == HIGH){
      digitalWrite(Twist_ENABLE, HIGH);
      digitalWrite(Lead_ENABLE, HIGH);
    }/*else{
      digitalWrite(Twist_ENABLE, LOW);
      digitalWrite(Lead_ENABLE, LOW);
    }*/
  TwisterCurrCount++;
  LeadCurrCount++;
//Serial.println("TwistISR");
  if(TwisterCurrCount >= TwisterSetCount){
    digitalWrite(Twist_STEP, HIGH);
    digitalWrite(Twist_STEP, LOW);
    TwisterCurrCount = 0;
  }
  if(LeadCurrCount >= LeadSetCount){
    digitalWrite(Lead_STEP, HIGH);
    digitalWrite(Lead_STEP, LOW);
    LeadCurrCount = 0;
  }
}

void TCPATwister::Initialize(){
//Attaching the TwisterISR to the Timer3 Interrupt.
  Timer3.attachInterrupt(CallISR);
//Configuring the Motor Control pins
  pinMode(Lead_STEP, OUTPUT);
  pinMode(Lead_DIR, OUTPUT);
  pinMode(Lead_ENABLE, OUTPUT);
  pinMode(Twist_STEP, OUTPUT);
  pinMode(Twist_DIR, OUTPUT);
  pinMode(Twist_ENABLE, OUTPUT);
//Configure the Limit Switch Pins
  pinMode(MOTOR_LIMIT, INPUT);
  pinMode(END_LIMIT, INPUT);
//The A4988 Motor Driver is a active low enable.
  digitalWrite(Twist_ENABLE, LOW);
  digitalWrite(Lead_ENABLE,LOW);
  digitalWrite(Lead_DIR,LEAD_START_DIR);
  digitalWrite(Twist_DIR,TWIST_START_DIR);
//  Serial.begin(9600);
//  Serial.println("H");
}

void SetTimerPeriod(long Period){
  Timer3.setPeriod(Period);
}
void TCPATwister::StartTimer(long Period){
  Timer3.initialize(Period);
  Timer3.start();
}
void TCPATwister::SetAcceleration(int rate){
  AccelerationRate = rate;
}
void TCPATwister::setTwistSetCount(int SetCount){
  TwisterSetCount = SetCount;
/* Debugging Code
  if (SetCount < 10){
    TwisterSetCount = SetCount;
  }else{
    TwisterSetCount = 10;
  }
 */
}
void TCPATwister::setLeadSetCount(int SetCount){
  LeadSetCount = SetCount;
}
int TCPATwister::getTwistSetCount(){
  return TwisterSetCount;
}
void TCPATwister::incTwistCount(){
  TwisterCurrCount++;
  if(TwisterCurrCount >= TwisterSetCount){
    digitalWrite(Twist_STEP, HIGH);
    digitalWrite(Twist_STEP, LOW);
    TwisterCurrCount = 0;
  }
}
static void TCPATwister::ForceStep(){
  digitalWrite(Twist_STEP, HIGH);
  digitalWrite(Twist_STEP, LOW);
}

//Due to ISRs being static methods, this roundabout method to attach the ISR to the Timer3 Interrupt must be used.
void TCPATwister::AttachInterrupt(void (*ISR)()){
  Timer3.attachInterrupt(ISR);
}
static TCPATwister& TCPATwister::SingletonTwister(){
  static TCPATwister Twister;
  return Twister;  
}
static void TCPATwister::CallISR(){
//  Serial.println("CallISR");
  TCPATwister::SingletonTwister().TwistISR();
}
void TCPATwister::setLeadDir(char dir){
  digitalWrite(Lead_DIR,dir);
  //digitalWrite(Twist_DIR,dir);
}
void TCPATwister::toggleLeadDir(){
  digitalWrite(Lead_DIR,!digitalRead(Lead_DIR));
  //digitalWrite(Twist_DIR,!digitalRead(Twist_DIR));
}
void TCPATwister::setTwistEnable(char enable){
  digitalWrite(Twist_ENABLE, enable);
}
void TCPATwister::setLeadEnable(char enable){
  digitalWrite(Lead_ENABLE, enable);
}
