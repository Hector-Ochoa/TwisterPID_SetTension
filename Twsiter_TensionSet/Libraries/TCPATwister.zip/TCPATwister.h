/*
 * Date: 4/18/18
 * Author: Collin Timmons
 * 
 * This code was written for the TCPA research group to control their muscle twister.
 * 
 * The code is designed to work with an Arduino Mega 2560 R3 with a rep-rap GPL3 3D printer motor control shield.
 * 
*/
#include <TimerThree.h>
#include "Arduino.h"

#define CONCAT(x,y) x ## y
#define CONCATMotor(x,y) CONCAT(x,y)

#ifndef TwistMotor
  #define TwistMotor X
#endif

#ifndef LeadMotor
  #define LeadMotor Z
#endif

//X Motor
#define DIR_X A1
#define STEP_X A0
#define ENABLE_X 38
//Y Motor
#define DIR_Y A7
#define STEP_Y A6
#define ENABLE_Y A2
//Z Motor
#define DIR_Z 48
#define STEP_Z 46
#define ENABLE_Z A8
//E0 Motor
#define DIR_E0 28
#define STEP_E0 26
#define ENABLE_E0 24
//E1 Motor
#define DIR_E1 34
#define STEP_E1 36
#define ENABLE_E1 30

//Optical Limit Switches
#define X_MIN 3
#define X_MAX 2
#define Y_MIN 14
#define Y_MAX 15
#define Z_MIN 18
#define Z_MAX 19

#define Twist_DIR CONCATMotor(DIR_,TwistMotor)
#define Twist_STEP CONCATMotor(STEP_,TwistMotor)
#define Twist_ENABLE CONCATMotor(ENABLE_,TwistMotor)
#define Lead_DIR CONCATMotor(DIR_,LeadMotor)
#define Lead_STEP CONCATMotor(STEP_,LeadMotor)
#define Lead_ENABLE CONCATMotor(ENABLE_,LeadMotor)

#define MOTOR_LIMIT 3
#define END_LIMIT 2

#define LEAD_START_DIR 0
#define TWIST_START_DIR 0



class TCPATwister{
  public:
    void Initialize();
    void SetTimerPeriod(long period);
    void StartTimer(long Period);
    void SetAcceleration(int rate);
    void setTwistSetCount(int SetCount);
    void setLeadSetCount(int SetCount);
    void incTwistCount();
    void TwistISR();
    void AttachInterrupt(void (*ISR)());
    static TCPATwister& SingletonTwister();
    static void CallISR();
    static void ForceStep();
    int getTwistSetCount();
    void setLeadDir(char);
    void toggleLeadDir();
    void setTwistEnable(char);
    void setLeadEnable(char);
  private:
    TCPATwister();
    int Period;
    int TwisterCurrCount;
    int TwisterSetCount;
    int LeadCurrCount;
    int LeadSetCount;
    int AccelerationRate;
};
